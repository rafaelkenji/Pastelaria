package pacote;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import pacote1.MomentoPag;
import pacote1.TipoPag;
import samplefx.ctrl.ClienteDAO;
import samplefx.ctrl.ClienteVO;
import samplefx.ctrl.FuncionarioDAO;
import samplefx.ctrl.FuncionarioVO;
import javafx.scene.control.Alert;
//import pacote.MaskTextField;

public class TelaPrincipalController implements Initializable {
	
	ClienteDAO cdao = new ClienteDAO();
	FuncionarioDAO fdao = new FuncionarioDAO();

/**************************************** FXML **************************************************************/
	
	/************** PANE **********************/
    @FXML
    private Pane CadCliente;
    
    @FXML
    private Pane NovaVenda;
    
    @FXML
    private Pane CadFunc;
    
    @FXML
    private Pane Consulta;
    
    @FXML
    private Pane Login;
   /********************************************/
    
   /************** MENU ************************/     
    @FXML
    private Button btnCadCliente;
    
    @FXML   
    private Button btnConsulta;
    
    @FXML
    private Button btnVenda;
    
    @FXML
    private Button btnLogOut;

    @FXML
    private Label lbTitulo;
    
    @FXML
    private Button Func;
    /******************************************************/
    
    /**************** TELA LOGIN *****************************/
    @FXML
    private TextField txtLogin;
    
    @FXML
    private PasswordField txtSenha;
    
    @FXML
    private Button btnLogin;
    /**************************************************************/
    
    /*********** CAD FUNC ****************************************/
    @FXML
    private Button BtnSalvarFunc;
    
    @FXML
    private TextField txtIdFuncionario;
    
    @FXML
    private TextField TxtNomeFuncionario;
    
    @FXML
    private TextField TxtSalario;
    
    @FXML
    private TextField TxtLoginFunc;
    
    @FXML
    private TextField TxtSenhaFunc;
    
    /*************************************************************/
    
    /************* CONSULTA ************************************/
    @FXML
    private Button BtnBuscarPed;
    /****************************************************************/
    
   
    /***************** CAD CLIENTE***********************************************/
    @FXML
    private TextField TxtNomeCliente;
    
    @FXML
    private TextField TxtNumero;
    
    @FXML
    private TextField TxtTelefone;
    
    @FXML
    private TextField TxtComplemento;
    
    @FXML
    private TextField TxtEndereco;
    
    @FXML
    private TextField txtId;
    
    @FXML
    private Button btnSalvarCliente;
    /**********************************************************************/
    
    /************** VENDA *****************************************/
    @FXML
    private Button BtnConfirmar;

    @FXML
    private ComboBox cbNome = new ComboBox();;
    
    @FXML
    private ComboBox<MomentoPag> cbMomento;
    private List<MomentoPag> momento = new ArrayList<>();
    private ObservableList<MomentoPag> obsmomento;
    
    @FXML
    private ComboBox<TipoPag> cbTipoPag;
    private List<TipoPag> tipos = new ArrayList<>();
    private ObservableList<TipoPag> obsTipos;
    
    /**************************************************************/
    
/********************************** **** *******************************************************************/	    
    
/******************************** M�TODOS  X ***************************************************************/
    private void FDisable(Pane tela) { // Disable = false
    	tela.setDisable(false);
    }
    
    private void TDisable() { // Disable = true
    	Consulta.setDisable(true);
    	CadCliente.setDisable(true);
    	CadFunc.setDisable(true);
    	NovaVenda.setDisable(true);
    }
    
    private void TOpacity(Pane tela) { //Opacity = 1
    	tela.setOpacity(1);
    }
    
    private void FOpacity() { // Opacity = 0
    	NovaVenda.setOpacity(0);
    	CadFunc.setOpacity(0);
    	Consulta.setOpacity(0);
    	CadCliente.setOpacity(0);
    }
    
    private void showAlertWithHeaderText(String tipo) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle( tipo + " Inserido");
        alert.setHeaderText(tipo +" Inserido com Sucesso!");
        alert.setContentText(tipo +" foi inserido na base de dados!");
 
        alert.showAndWait();
    }
    
    private void alertaErro(String tipo) {
    	Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
		dialogoErro.setTitle("ERRO");
		dialogoErro.setHeaderText(tipo +" n�o preenchido/a corretamente");
		//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
		dialogoErro.showAndWait();
    }
    
    public void LimpaCampos() {
    	TxtNomeCliente.clear();
    	TxtNumero.clear();
    	TxtTelefone.clear();
    	TxtComplemento.clear();
    	TxtEndereco.clear();
    	txtId.clear();
    	txtLogin.clear();
		txtSenha.clear();
		txtIdFuncionario.clear();
	    TxtNomeFuncionario.clear();
	    TxtSalario.clear();
	    TxtLoginFunc.clear();
	    TxtSenhaFunc.clear();
    }
    
/******************************** ********** ***************************************************************/
    
/********************************* COMBO  BOX **************************************************************/
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		carregarMomento();
		carregarTipos();
		try {
			cdao.ConsultaCliente(cbNome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    
    public void carregarMomento() {
		
		MomentoPag momento1 = new MomentoPag(1,"Em casa");
		MomentoPag momento2 = new MomentoPag(2,"No estabelecimento");
		
		momento.add(momento1);
		momento.add(momento2);
		
		obsmomento = FXCollections.observableArrayList(momento);
		
		cbMomento.setItems(obsmomento);
		
	}
    
    public void carregarTipos() {
		
		TipoPag tipo1 = new TipoPag(1,"Dinheiro");
		TipoPag tipo2 = new TipoPag(2,"Cart�o de Cr�dito");
		TipoPag tipo3 = new TipoPag(3,"Cart�o de D�bito");
		
		
		tipos.add(tipo1);
		tipos.add(tipo2);
		tipos.add(tipo3);
		
		
		obsTipos = FXCollections.observableArrayList(tipos);
		
		cbTipoPag.setItems(obsTipos);
		
	}
   
    /********************************* ********** **************************************************************/
    
    /********************************* TELA DE LOGIN ***********************************************************/
    @FXML
    void FazerLogin(ActionEvent event) {
    
    		if(txtLogin.getText()==null || txtLogin.getText().trim().equals("")){
    		  
    			alertaErro("Login");
    			
    		}
    		else if(txtSenha.getText()==null || txtSenha.getText().trim().equals("")){
    			alertaErro("Senha");
    		}
    		else {
    			Login.setDisable(true);
    			Login.setOpacity(0);
    			btnCadCliente.setVisible(true);
    			btnLogOut.setVisible(true);
    			btnConsulta.setVisible(true);
    			btnVenda.setVisible(true);
    			Func.setVisible(true);
    			LimpaCampos();	
    		}
    }
    
   
    
    /********************************* ************* ***********************************************************/
    
    /********************************* NOVA VENDA **************************************************************/
    @FXML
    void Confirmar(ActionEvent event) {

    }

    /********************************* ********** **************************************************************/
    
    /********************************* CAD CLIENTE *************************************************************/
    @FXML
    void SalvarCliente(ActionEvent event) {
    	
    	if(txtId.getText()==null ||txtId.getText().trim().equals("")){
  		  
    		alertaErro("ID");
		}
    	else if(TxtNomeCliente.getText()==null || TxtNomeCliente.getText().trim().equals("")){
    		alertaErro("Nome");
			
		}
    	else if(TxtTelefone.getText()==null || TxtTelefone.getText().trim().equals("")){
    		alertaErro("Telefone");
			
		}
    	else if(TxtEndereco.getText()==null || TxtEndereco.getText().trim().equals("")){
    		alertaErro("Endere�o");
			
		}
    	else if(TxtNumero.getText()==null || TxtNumero.getText().trim().equals("")){
    		alertaErro("N�mero");
			
		}
    	else if(TxtComplemento.getText()==null || TxtComplemento.getText().trim().equals("")){
    		alertaErro("Complemento");
			
		}
    	else {
    	ClienteVO c = new ClienteVO();
    	c.setId(Integer.parseInt(txtId.getText()));
    	c.setNome(TxtNomeCliente.getText());
    	c.setTelefone(TxtTelefone.getText());
    	c.setEndereco(TxtEndereco.getText());
    	c.setNumero(Integer.parseInt(TxtNumero.getText()));
    	c.setComplemento(TxtComplemento.getText());
    	
    	cdao.InserirCliente(c);
    	showAlertWithHeaderText("Cliente");
    	LimpaCampos();
    	}
    }
    
    /********************************* *********** *************************************************************/
    
    /********************************* MENU ********************************************************************/
    @FXML
    void LogOut(ActionEvent event) {
    	FDisable(Login);
    	TDisable();
    	FOpacity();
    	TOpacity(Login);
    	btnCadCliente.setVisible(false);
    	btnConsulta.setVisible(false);
    	btnVenda.setVisible(false);
    	Func.setVisible(false);
    	btnLogOut.setVisible(false);
    	lbTitulo.setText("PASTELARIA DO JAILSON");
    	txtLogin.requestFocus();
    }
     
    @FXML
    void Venda(ActionEvent event) {//M�todo acontece quando clica no bot�o nova venda
    	
    	TDisable();
    	FDisable(NovaVenda);
    	FOpacity();
    	TOpacity(NovaVenda);
    	lbTitulo.setText("NOVA VENDA");
    }
    
    @FXML
    void Consultar(ActionEvent event) {//M�todo acontece quando clica no bot�o Consultar
    	
    	TDisable();
    	FDisable(Consulta);
    	FOpacity();
    	TOpacity(Consulta);
    	lbTitulo.setText("CONSULTA DE PEDIDO");
    }
    
    @FXML
    void Cadastrar(ActionEvent event) { //M�todo acontece quando clica no bot�o cadastrar cliente
    	
    	TDisable();
    	FDisable(CadCliente);
    	FOpacity();
    	TOpacity(CadCliente);
    	lbTitulo.setText("CADASTRO DE CLIENTE");
    	txtId.requestFocus();
    }
    
    @FXML
    void CadFuncs(ActionEvent event) {//M�todo acontece quando clica no bot�o cadastrar funcion�rio
    	
    	TDisable();
    	FDisable(CadFunc);
    	FOpacity();
    	TOpacity(CadFunc);
    	lbTitulo.setText("CADASTRO DE FUNCION�RIO");
    	txtIdFuncionario.requestFocus();
    }
    
    /********************************* **** ********************************************************************/
    @FXML
    void BuscarPed(ActionEvent event) {

    }

   
 
    /************************ CAD FUNC ************************************************************************/
    @FXML
    void SalvarFunc(ActionEvent event) {
    	if(txtIdFuncionario.getText()==null ||txtIdFuncionario.getText().trim().equals("")){
    		alertaErro("ID");
		}
    	else if(TxtNomeFuncionario.getText()==null || TxtNomeFuncionario.getText().trim().equals("")){
    		alertaErro("Nome");
		}
    	else if(TxtSalario.getText()==null || TxtSalario.getText().trim().equals("")){
    		alertaErro("Sal�rio");
		}
    	else if(TxtLoginFunc.getText()==null || TxtLoginFunc.getText().trim().equals("")){
    		alertaErro("Login");
		}
    	else if(TxtSenhaFunc.getText()==null || TxtSenhaFunc.getText().trim().equals("")){
    		alertaErro("Senha");
		}
    	else {
    	FuncionarioVO f = new FuncionarioVO();
    	f.setId(Integer.parseInt(txtIdFuncionario.getText()));
    	f.setNome(TxtNomeFuncionario.getText());
    	f.setSalario(TxtSalario.getText());
    	f.setUsuario(TxtLoginFunc.getText());
    	f.setSenha(TxtSenhaFunc.getText());
    	
    	fdao.InserirFuncionario(f);
    	showAlertWithHeaderText("Funcion�rio");
    	LimpaCampos();
    	}
    }
    /*******************************************************************************************************/
}
