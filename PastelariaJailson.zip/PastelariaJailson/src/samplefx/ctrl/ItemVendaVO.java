package samplefx.ctrl;

public class ItemVendaVO {
	int idVenda;
	public int getIdVenda() {
		return idVenda;
	}
	public void setIdVenda(int idVenda) {
		this.idVenda = idVenda;
	}
	public int getIdFuncionario() {
		return idFuncionario;
	}
	public void setIdFuncionario(int idFuncionario) {
		this.idFuncionario = idFuncionario;
	}
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public int getIdVendaItem() {
		return idVendaItem;
	}
	public void setIdVendaItem(int idVendaItem) {
		this.idVendaItem = idVendaItem;
	}
	public String getFormaDePagamento() {
		return FormaDePagamento;
	}
	public void setFormaDePagamento(String formaDePagamento) {
		FormaDePagamento = formaDePagamento;
	}
	public String getMomentoPag() {
		return MomentoPag;
	}
	public void setMomentoPag(String momentoPag) {
		MomentoPag = momentoPag;
	}
	int idFuncionario;
	int idCliente;
	int idVendaItem;
	String FormaDePagamento;
	String MomentoPag;
	
}
