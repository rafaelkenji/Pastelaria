package samplefx.ctrl;
import java.sql.Connection;
	import java.sql.Date;
	import java.sql.PreparedStatement;
public class ProdutoDAO {

	
	
	

		

		
			private static Connection connection;
			
			public ProdutoDAO() {
				connection = DbUtil.getConnection();
			}
			
			public void InserirItemVenda (ProdutoVO v) { //mudar para incluir
				
				try {
					
					PreparedStatement preparedStatement = connection.prepareStatement(
							"INSERT INTO ItemVenda (idVenda, idProduto, quantidade) VALUES (?, ?, ?)");
					
					preparedStatement.setInt(1,v.getId());
					preparedStatement.setString(2, v.getProduto());
					preparedStatement.setInt(3, v.getPreco());
					preparedStatement.execute();
					
					
					}catch (Exception e) {
					e.printStackTrace();
										}
				
			}
		}


	


