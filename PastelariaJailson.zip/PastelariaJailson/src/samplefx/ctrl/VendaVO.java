package samplefx.ctrl;

public class VendaVO {
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdprod() {
		return idprod;
	}
	public void setIdprod(int idprod) {
		this.idprod = idprod;
	}
	public String getPagamento() {
		return pagamento;
	}
	public void setPagamento(String pagamento) {
		this.pagamento = pagamento;
	}
	public String getMomentoPagamento() {
		return momentoPagamento;
	}
	public void setMomentoPagamento(String momentoPagamento) {
		this.momentoPagamento = momentoPagamento;
	}
	int id;
	int idprod;
	String pagamento;
	String momentoPagamento;
	
}
