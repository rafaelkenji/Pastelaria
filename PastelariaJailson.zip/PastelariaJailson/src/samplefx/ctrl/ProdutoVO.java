package samplefx.ctrl;

public class ProdutoVO {
int id;
public int getId() {
	return id;
}
public String getProduto() {
	return produto;
}
String produto;
int preco;
public int getPreco() {
	return preco;
}

}
