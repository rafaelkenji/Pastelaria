package samplefx.ctrl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class VendaDAO {

	
		private static Connection connection;
		public VendaDAO() {
			connection = DbUtil.getConnection();
		}
		
		public void InserirVenda (VendaVO v) { //mudar para incluir
			
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"INSERT INTO Venda (?, ?) VALUES (?, ?)");
				
				
				preparedStatement.setInt(1,v.getId());
				preparedStatement.setInt(2,v.getIdprod());
				preparedStatement.setString(3, v.getPagamento());
				preparedStatement.setString(4, v.getMomentoPagamento());
				}
				
	
				
			
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		public int ConsultaVenda (int venda) throws SQLException {
			int id = 0;
			try {
				Statement st =  connection.createStatement();
				ResultSet rs = st.executeQuery("SELECT * from ? where ? = '" + venda + "'");
				
				while (rs.next()) {
				      id = rs.getInt(1);
				      return id;
				    }
				

	        } catch (SQLException ex) {
	            System.err.println("Error"+ex);
	        }
			return id;
		}
}
	
	
	

