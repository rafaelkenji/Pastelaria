package samplefx.ctrl;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

public class ItemVendaDAO {
	

	
		private static Connection connection;
		
		public ItemVendaDAO() {
			connection = DbUtil.getConnection();
		}
		
		public void InserirItemVenda (ItemVendaVO v) { //mudar para incluir
			
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"INSERT INTO ItemVenda (idVenda, idProduto, quantidade) VALUES (?, ?, ?)");
				
				preparedStatement.setInt(1,v.getIdVenda());
				preparedStatement.setInt(2, v.getIdFuncionario());
				preparedStatement.setString(3, v.getFormaDePagamento());
				preparedStatement.setString(4, v.getMomentoPag());
				preparedStatement.setInt(5, v.getIdVendaItem());
				preparedStatement.execute();
				
				/*
		}
	public int getIdVendaItem() {
		return idVendaItem;
	}
				 */
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}

