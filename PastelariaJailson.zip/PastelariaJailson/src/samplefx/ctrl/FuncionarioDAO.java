package samplefx.ctrl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class FuncionarioDAO {

	//TODO: Add
	//TODO: Update
	//TODO: Delete
	
	private static Connection connection;
	
	public FuncionarioDAO() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirFuncionario(FuncionarioVO f) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"Insert into Funcionarios values (?,?,?,?,?)" );
			
					preparedStatement.setInt(1, f.getId());
					preparedStatement.setString(2, f.getNome());
					preparedStatement.setString(3, f.getSalario());
					preparedStatement.setString(4, f.getUsuario());
					preparedStatement.setString(5, f.getSenha());

					
					

			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
